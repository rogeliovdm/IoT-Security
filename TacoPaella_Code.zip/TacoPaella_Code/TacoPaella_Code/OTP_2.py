# import time
# from Crypto.Util.number import long_to_bytes
# import hashlib

# def encrypt(b):
#     key = 0xa8994fab1ce2a0f57131223be48d2d00aa98e6abffd1dbe6d56dc294d34dcfa9
#     key_bytes = long_to_bytes(key)
#     assert len(b) <= len(key_bytes), "Data package too large to encrypt!"
#     return otp(key_bytes, b)

# def otp(a, b):
#     ciphertext = b''
#     for i in range(len(b)):
#         ciphertext += bytes([a[i] ^ b[i]])
#     return ciphertext.hex()

# def main():
#     challenge = "0000000000000000000000000000000"
#     print(f"string introduced: {(challenge.encode('utf-8'))}")
#     print(f"encrypted_challenge: {encrypt(challenge.encode('utf-8'))}")

# main()
import time
from Crypto.Util.number import long_to_bytes
import hashlib

def encrypt(b):
    key = 0xe69a8eed2308b75e33488a1c1c53f445509d66a27da12fd55d9fe239e6c1ed03
    key_bytes = long_to_bytes(key)
    assert len(b) <= len(key_bytes), "Data package too large to encrypt!"
    return otp(key_bytes, b)

def otp(a, b):
    ciphertext = b''
    for i in range(len(b)):
        result = a[i] ^ b[i]
        ciphertext += bytes([result])
        print(f"Byte {i}: {hex(a[i])} XOR {hex(b[i])} = {hex(result)}")
    return ciphertext.hex()
#encrypted flag XOR "31 spaces" == enrypted flag XOR 0x20....0x20 (31 times 0x20)
#one example:
#encrypted challenge after sending 31 spaces is e69a8eed2308b75e33488a1c1c53f445509d66a27da12fd55d9fe239e6c1ed03
# XORING the encrypted challenge again with the 31 spaces will get you the key (because these are not 0) which is c6baaecd0328977e1368aa3c3c73d46570bd46825d810ff57dbfc219c6e1cd
# simply send 1 to get an encrypted flag, which was afd5dabe664bec30761ecf6e6326a7202ff212d202ea6aac2ee0966e8f82a873
# XOR the encrypted glag (C2) with the key you got from before and you will get the plaintext
#You will get
#iotsec{NeveR_UsE_OTP_keYS_TwIce}
def main():
    challenge = "                               "
    print(f"string introduced: {(challenge.encode('utf-8'))}")
    encrypted_challenge = encrypt(challenge.encode('utf-8'))
    print(f"encrypted_challenge: {encrypted_challenge}")

main()

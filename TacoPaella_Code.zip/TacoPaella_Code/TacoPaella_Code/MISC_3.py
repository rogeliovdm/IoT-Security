ciphertext = "aW90c2Vje2VuQ09kSW5HX0lzX25PVF9lTkNSWXB0aU9OfQ=="
print(len(ciphertext))


# Code from the internet (stackoverflow)
def print_grid(string, rows, columns):
    # Pad the string with spaces to fit the grid
    string = string.ljust(rows * columns)
    # Create the grid
    grid = [string[i:i+columns] for i in range(0, rows * columns, columns)]
    # Print the grid
    for row in grid:
        print(' '.join(row))


import base64


ciphertext = "aW90c2Vje2VuQ09kSW5HX0lzX25PVF9lTkNSWXB0aU9OfQ=="
decoded_bytes = base64.b64decode(ciphertext)
decoded_message = decoded_bytes.decode('utf-8')

print("Decoded message:", decoded_message)


''' RSA: Do you need this file? '''


n=1807082088687404805951656164405905566278102516769401349170127021450056662540244048387341127590812303371781887966563182013214880557
e=3
c=1652208693550034693651720890316822542413928619088782298650002304794448273274914517015936341386453027000810243592099691059332598640


# Using the tool factordb we figured out the 2 primer factors, p and q, that form n
p = 39685999459597454290161126162883786067576449112810064832555157243
q = 45534498646735972188403686897274408864356301263205069600999044599


from Crypto.Util.number import inverse
import math 

def small_exponent_attack(ciphertext, public_exponent, modulus):
    # Compute the plaintext by taking the modular root of the ciphertext
    plaintext = pow(ciphertext, inverse(public_exponent, modulus), modulus)
    return plaintext



# plaintext = small_exponent_attack(c, e, n)
# print(plaintext)
# plaintext = hex(plaintext) # string with hex values
# plaintext = "074aa03eceb2822baa28a740fd6820f73637e63f6e43751dc207bf658eda0af2bd1a2d38638651e8d6530ef7819bb010da42543342de"
# print("plaintext with hex values ", plaintext)
# plaintext = bytes.fromhex(plaintext) # [0][2:] to eliminate the 0x at the beginning
# print(plaintext) 
# print()
# print(plaintext.decode('utf-8', errors="ignore"))




# print(f"{plaintext=}")
# plaintext_bytes = bytes.fromhex(f"{plaintext:x}")
# readable_plaintext = plaintext_bytes.decode('utf-8')
# print(readable_plaintext[128], readable_plaintext[129], readable_plaintext[130])
# print("Readable plaintext:", readable_plaintext)

# plaintext = 315889
# print("plaintext ", plaintext)
# print(f"{plaintext}")
# bytes_plaintext = bytes.fromhex(f"{plaintext}")
# readable_plaintext = bytes_plaintext.decode('utf-8')
# print(readable_plaintext)

# m = "))"
# print(m.encode())
# print(m.encode().hex())
# m_i = int(m.encode().hex(), 16)
# print(m_i)


# print("hex format of plaintext: ", f"{plaintext:x}")
# readable_plaintext = bytes.fromhex((f"{plaintext:x}")).decode('utf-8')
# readable_plaintext = bytes.fromhex("74aa03eceb2822baa28a740fd6820f73637e63f6e43751dc207bf658eda0af2bd1a2d38638651e8d6530ef7819bb010da42543342de").decode('utf-8')
# print(readable_plaintext)



def rsa_cube_root_decrypt(n, e, c):
    plaintext = int(math.pow(c, 1/3))  # Compute cube root of ciphertext

    # Convert the plaintext to a byte string
    byte_length = (plaintext.bit_length() + 7) // 8
    plaintext_bytes = plaintext.to_bytes(byte_length, 'big')

    return plaintext_bytes  




# Euler's totient function phi = (p-1)*(q-1)
phi = (p-1)*(q-1)
d = inverse(e, phi)
plaintext = pow(c, d, n)
print("plaintext: ", plaintext)
readable_plaintext = bytes.fromhex(f"{plaintext:x}").decode('utf-8')
print(readable_plaintext)
from Crypto.Util.number import GCD, inverse 

e = "10001"
e_int = int(e, 16)
n = "aaf3ebb0ef9bacc9dc5029a9469a164d4478f06903d7e9afc9b6883fc78a93abf413ffffc74559325890a353d9fe3af3367eb912100d80d1fafc511d3c50227f8022a737bbe888e2f779a52d2f2f14336a6b8cf036b9ee34fc6d3c680605ce97c4333fdbac3006a60a84850a639e95464e2eb02ffeef401909ed776efd02076f"
n_int = int(n, 16)

''' --- ciphertext: Received from server --- '''
ciphertext = "6368616c6c656e67655f61633734303533643565386161306363"
ciphertext_int = int(ciphertext, 16)
r = "B"
r_int = int(r, 16)
print("r_int: ", r_int)
r_e_mod_n = pow(r_int, e_int, n_int)
print("r^e mod n: ", r_e_mod_n)

c_prime = (ciphertext_int * r_e_mod_n) % n_int
c_prime_hex = f"{c_prime:x}"
print("c_prime_hex is: ", c_prime_hex)


''' --- c_prime_d: Received from server --- '''
c_prime_d = "85513bc0e90b497147cd3805ee6e61c3cef805b48952f40db5d1980826492cdf70220991dee5121c532e528181d80dca42ce6565718312893e29333f280450294880988fd680eb150b3a75bb68be7c301f7b61a571113f924764ae669fa77aceb6f5091818b45460a0a23dc0042dc7ac3860afc97cb34f98eb2a2f337fc1f46a"
print("length of receiverd c_prime_d: ", len(c_prime_d))
c_prime_d_int = int(c_prime_d, 16)
r_inverse_int = inverse(r_int, n_int)

plaintext_int = (c_prime_d_int * r_inverse_int) % (n_int)
plaintext = f"{plaintext_int:x}"
print()
print("The plaintext (hex) is: ", plaintext)

# print("The GCD is: ", GCD(r_int, n_int))
# assert GCD(r_int, n_int) == 1

from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

#In this program the next steps are followed
#1. open and read the files and store them as they are in a variable (One variable for each file)
#2. Give the IV a 16 bytes '0x00' value 
#3. Copy and paste the given key from the challenge file
#4. Create a C1 "cipherext" object from AES library with the given key, the 0 vector and the CBC mode selected
#5. Decrypt the data from the temp_enc file and store it in a temporal variable
#6. Perform XOR operations for the first 2 blocks of the plaintext to find the IV
#7. With the IV found just use it with the key to generae a C2 object from AES library
#8. Decrypt C2 containinng the secret_enc data

with open('./secret_readings.enc', 'rb') as f:
    secret_enc = f.read()

with open('./temp_readings.enc', 'rb') as f:
    temp_enc = f.read()

#Start your IV with 32 0s i.e 16 bytes
iv = bytes.fromhex('00000000000000000000000000000000')
#Copy the given key
key = bytes.fromhex('1ea349c9e1cdd4ccd6096bff136941a1')
#Call AES function from Crypto.Cipher. Key and IV as inputs, CBC mode selected
cipher = AES.new(key, AES.MODE_CBC, iv)


#We then decrypt the data from the temp_enc file to find the initialization vector

temp = cipher.decrypt(temp_enc)
#grab first block of decrypted data
temp_block_1 = temp[:16]  # plaintext block 1
#grab 2nd block of decrypted data
temp_block_2 = temp[16:32] # plaintext block 2

# For getting the IV follow the same logic as OTP -> plaintext XOR intermediate value = IV 
result = []
for a, b in zip(temp_block_1, temp_block_2):
    #Append each XORed operation to store the whole string of bytes and not only the last one
    result.append(a ^ b)

real_iv = bytes(result).hex()

# Once we have the correct IV, we use it for the decryption of the secret data
iv = bytes.fromhex(real_iv)
key = bytes.fromhex('1ea349c9e1cdd4ccd6096bff136941a1')
cipher = AES.new(key, AES.MODE_CBC, iv)

secret_dec = cipher.decrypt(secret_enc)
#decrypt data
print(secret_dec)

#result is:            iotsec{Keep_yOuR_kEyS_SeCreT_at_aNyTImE}
#with unpad result is: iotsec{Keep_yOuR_kEyS_SeCreT_at_aNyTImE}
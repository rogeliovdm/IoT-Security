def utf8_to_hex(input_string):
    # Convert the input string to bytes using UTF-8 encoding
    encoded_bytes = input_string.encode('utf-8')

    # Convert the encoded bytes to hexadecimal representation
    hex_representation = encoded_bytes.hex()

    return hex_representation


# El mensaje encriptado tiene una longitud de 90 caracteres
# El mensaje en hex tiene una longitud de 180 caracteres


def repeat_character(char, num):
    if num <= 0:
        return ""

    repeated_string = char * num
    return repeated_string


def one_time_pad_decrypt2(ciphertext, key):
    ciphertext_bytes = bytes.fromhex(ciphertext)
    key_byte = key.encode('utf-8')
    plaintext_bytes = bytes([ciphertext_byte ^ key_byte[0] for ciphertext_byte in ciphertext_bytes])
    plaintext = plaintext_bytes.decode('utf-8')

    return plaintext



def hex_to_ascii(my_hex_string):


    string_bytes = bytes.fromhex(my_hex_string)
    print(string_bytes)
    return string_bytes.decode('utf-8')

file_path = 'flag2.txt'
ciphertext = ""
with open(file_path, 'r') as file:
    ciphertext = file.readline()
print("The enc. message has length: ", len(ciphertext))


for i in range(0, 127):
    key = chr(i)
    plaintext = one_time_pad_decrypt2(ciphertext, key)
    print("plaintext: ", plaintext, "with key: ", chr(i), "i: ", i)

# noooooo VALOR CORRECTO: 'N', unicode number 78

print()

my_hex_string = "211a1e31050b373d31231b1d3a310c2b313c2f002a0103312f200a313d3b2828272d072b003a02373102210029"
print(hex_to_ascii(my_hex_string))
print()
print()


otp_key = bytes.fromhex("4e")
msg_enc = bytes.fromhex(my_hex_string)
# 1. Decrypt the received data
msg_dec = bytearray(len(msg_enc))
for i in range(len(msg_enc)):
    # Bytewise XOR with key
    msg_dec[i] = msg_enc[i] ^ otp_key[0]

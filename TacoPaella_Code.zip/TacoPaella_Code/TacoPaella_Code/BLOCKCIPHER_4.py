import socket

IP = '10.157.150.3'
PORT = 50001
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

sock.connect((IP, PORT))
response_garbage = sock.recv(2048)


def send_and_receive_data(message):
    sock.send(message.encode('utf-8'))
    response1 = sock.recv(2048)
    return response1


'''
ENCRYPTION SERVER

Given an encrypted block with one unknown encrypted character, iterate over all possible ascii values until
the value that generated that exact block is found.

-- inputs --

current_message: current message sent to the server.
reference_block: block we get from server where there is at least one character of the secret.

'''
first_block = "61616161616161616161616161616161" # letter 'a' repeated 16 times in hex. Will never be changed.

def find_original_character(current_message, reference_block): 
    correct_char = ''
    # 65 - 126 characters that our flag can have (capital and small leters, and '_', '{' ,'}')
    for i in range(65,126):
        trial = get_block_from_server(current_message, i) # Received message block from the server with current ascii character guess.
        # print("current_guess:", chr(i))
        if trial == reference_block:
            correct_char = chr(i)
            return correct_char


def get_block_from_server(current_message, i):
    # second_block_query = current_message[:-1] + hex(i)
    # second_block_query = current_message + format(i, "x")

    # total_query = first_block + second_block_query
    total_query = current_message + format(i, "x")
    contador = 1
    if contador:
        # print("total_query length:",len(total_query))
        contador = 0
    # print(f"{total_query=}")

    # SEND QUERY TO SERVER
    # server_answer = send_and_receive_data(total_query).decode('utf-8')
    server_answer = send_and_receive_data(total_query)[32:63].decode('utf-8')
    # print(f"{server_answer=}")

    return server_answer



print("\n \n --- ACTUAL EXECUTION")


def crack_server():
    characters = ""
    string_16_plus_16 = "6161616161616161616161616161616161616161616161616161616161616161"
    zero_message_from_server = send_and_receive_data(string_16_plus_16).decode('utf-8')
    # print("first part: ", zero_message_from_server[0:31])
    # print("second part: ", zero_message_from_server[32:64])
    assert zero_message_from_server[0:31] == zero_message_from_server[32:63]

    for i in range(30):
        characters_length = 2 + 2*len(characters)
        # to remover the 16th, 15th, etc letters, that is, two hex values per letters (eg. 0x5f).
        reference_block = send_and_receive_data(string_16_plus_16[:-characters_length]).decode('utf-8')[32:63]
        print("reference block:", reference_block)
        #variable that holds 15 bytes + 1 random, 14 + 1st guess + 1 random, etc.
        hex_string_to_send = string_16_plus_16[:-characters_length]
        for x in range(len(characters)):
            hex_string_to_send = hex_string_to_send + format(ord(characters[x]), "x")
        new_character = find_original_character(hex_string_to_send, reference_block)
        if new_character == None:
            print(f"{characters=}")
        characters = characters + new_character
        # print(characters)
    print(f"{characters=}")


crack_server()

# sock.close()
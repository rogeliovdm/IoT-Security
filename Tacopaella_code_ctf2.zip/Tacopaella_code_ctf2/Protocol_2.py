from Crypto.Cipher import AES
import binascii

key = binascii.unhexlify('ef0973bb3c8d81ce1ad157c45d2c435e803c84262cfbc117814df4f090c36701')
iv = binascii.unhexlify('8a979a57a3efa63a6de2e09385ffc4a1')
ciphertext = binascii.unhexlify('16e850ae4d507e786b6fc530891ba3270c0baf7924bedd8f2a45d3fa8c48062252be17c004232b64e99c0a2f13e1d0c3b67c1f712ef952cf570e638e9f84057d8294fae3d7839677b7c040c29386e4334d27986b45e61e2ebf90255c21dcc9e14977ae48169f6d9e744deb75d023ae15eb940fd503f0a1ccdff84993f4c190f125ce26174bac090a3a49fdfe50855c94')

cipher = AES.new(key, AES.MODE_CBC, iv)
plaintext = cipher.decrypt(ciphertext)

try:
    decrypted_message = plaintext.decode('utf-8')
except UnicodeDecodeError:
    decrypted_message = plaintext.decode('latin-1')

print("Decrypted Message:", decrypted_message)

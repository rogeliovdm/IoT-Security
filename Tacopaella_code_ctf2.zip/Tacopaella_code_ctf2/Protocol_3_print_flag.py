import itertools

string = "iotsec{prime_numbeRs_In_diffIe_HeLlman_MuST_bE_sUFfICienTly_LarGE}"
substring = "prime_num"

# Generate all possible combinations of lowercase and uppercase letters for the first 9 characters
combinations = []
for r in range(len(substring) + 1):
    combinations.extend(itertools.combinations(range(len(substring)), r))

# Print the whole string with each variation of the first 9 characters, enumerated
for i, combo in enumerate(combinations, 1):
    result = ""
    for j, char in enumerate(string):
        if j in range(string.index(substring), string.index(substring) + len(substring)):
            if j - string.index(substring) in combo:
                result += char.upper()
            else:
                result += char.lower()
        else:
            result += char
    print("#{}: {}".format(i, result))

import paho.mqtt.client as mqtt

###############################
#          Constants          #
###############################
username = 'roger'
password = 'password'

def on_connect(client, userdata, flags, rc):
    print(f"Connected with result code {rc}")
    # Subscribe to thespecific topic "Topics/default/info"
    client.subscribe("Topics/#")

def on_message(client, userdata, msg):
    print(f"Received message on topic: {msg.topic}\nMessage: {msg.payload.decode()}\n")

# Create an MQTT client
client = mqtt.Client()

# Set callback functions
client.on_connect = on_connect
client.on_message = on_message

# Connect to the MQTT broker
client.username_pw_set(username, password)
client.connect("10.157.150.3", 1883)

# Start the network loop
client.loop_forever()

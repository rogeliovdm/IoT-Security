from sympy import symbols, Eq, mod_inverse
import base64
import hashlib
import binascii
from Crypto.Cipher import AES



#-----------------------Variables obtained from Wireshark in Kali
# p = f0809
p = 985097
# g = 2
g = 2
# s = 460c4
S = 286916
# c = 4dff7
C = 319479


#-----------Baby step function to get secret a/b 
def baby_step_giant_step(X, p, g):
    m = int(p ** 0.5) + 1

    # Precompute values of g^j mod p for j = 0 to m-1
    g_values = {0: 1}
    for j in range(1, m):
        g_values[j] = pow(g_values[j - 1] * g, 1, p)

    # Calculate the inverse of g^m mod p
    inv_g_m = mod_inverse(g_values[m - 1], p)

    # Search for a match between X and g^j mod p
    for i in range(m):
        rhs = X * mod_inverse(g_values[i], p) % p
        if rhs in g_values.values():
            j = next(key for key, value in g_values.items() if value == rhs)
            b = (i * m + j) % p
            return b

    return None


#-----------Decrypt AES function 
def decrypt(ciphertext, key, iv_hex):
    # Convert key and ciphertext from hexadecimal to bytes
    key = binascii.unhexlify(key)
    ciphertext = binascii.unhexlify(ciphertext)
    iv = binascii.unhexlify(iv_hex)

    # Create AES cipher object with key and mode
    cipher = AES.new(key, AES.MODE_CBC, iv)


    # Decode the decrypted bytes using 'latin-1' encoding
    decrypted = cipher.decrypt(ciphertext)
    # decrypted = unpad(decrypted, AES.block_size)

    return decrypted.hex()


# Calculate a
a = baby_step_giant_step(S, p, g)
print(f"a is = {a}")

# calculate Key from a 
K = (C**a)%p

# Get the hexadecimal representation of the hashed key
hashed_value = hashlib.sha256(str(K).encode()).hexdigest()


#  usage
#wrong IV don't use this! (copied it wrongly from Wireshark) added 00 bytes padding to match 16-byte length 
#IV = '1dd8fdd7147f02300000000000000000'
IV= '1dd8fdd7147f023769008bee961ef330'
ciphertext = '986ea352063be6fc73359f58ec43469f8c1897ddf8e0513cf0e50294d8598d7125994070e08b8637b18697c42fbb86cf6cf053c456edc04f942de69ffda4bec98dccf8cf79e3447f9a53be96311f0261'

#print plaintext (flag!)
plaintext = decrypt(ciphertext, hashed_value, IV)
print("Decrypted plaintext:", plaintext)